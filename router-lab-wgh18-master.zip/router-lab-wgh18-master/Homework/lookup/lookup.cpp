#include "router.h"
#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <iostream>
using namespace std;


//DictTree *begin_ = new DictTree();
vector<RoutingTableEntry> begin_;
/* 插入时如果已经存在一条 addr 和 len 都相同的表项，则替换掉原有的。*/
void insertt(RoutingTableEntry entry){
    for(int i = 0;i < begin_.size();i++){
        if(begin_[i].addr == entry.addr && begin_[i].len == entry.len){
            begin_[i]= entry;
            return ;
        }
    }
//    printf("insert 0x%08x %d %08x %d\n", entry.addr, entry.len, entry.nexthop, entry.if_index);
//    cout << "insert : " << entry.addr << " " << entry.len << " " << entry.if_index << " " << entry.nexthop << endl;
    begin_.push_back(entry);
//  DictTree *now = begin_;
//  // cout << "in lookup.cpp 2.0 \n";
//  while(now->next != nullptr){
//    // cout << now->e.if_index << " ";
//    now = now->next;
//  }
//  // cout << endl;
//
//  // cout << "in lookup.cpp 2.1 \n";
//  now->next = new DictTree(entry);
//  // cout << "in lookup.cpp 2.2 \n";
//  now->next->bef = now;
}

void deletee(uint32_t addr,uint32_t len){
    for(int i = 0;i < begin_.size();i++) {
        if(begin_[i].addr == addr && begin_[i].len == len) {
            RoutingTableEntry e = begin_[begin_.size()-1];
            begin_[begin_.size()-1]=begin_[i];
            begin_[i]=e;
            begin_.pop_back();

            return ;
        }
    }
}
/*
  RoutingTable Entry 的定义如下：
  typedef struct {
    uint32_t addr; // 大端序，IPv4 地址
    uint32_t len; // 小端序，前缀长度
    uint32_t if_index; // 小端序，出端口编号
    uint32_t nexthop; // 大端序，下一跳的 IPv4 地址
  } RoutingTableEntry;

  约定 addr 和 nexthop 以 **大端序** 存储。
  这意味着 1.2.3.4 对应 0x04030201 而不是 0x01020304。
  保证 addr 仅最低 len 位可能出现非零。
  当 nexthop 为零时这是一条直连路由。
  你可以在全局变量中把路由表以一定的数据结构格式保存下来。
*/

/**
 * @brief 插入/删除一条路由表表项
 * @param insert 如果要插入则为 true ，要删除则为 false
 * @param entry 要插入/删除的表项
 *
 * 插入时如果已经存在一条 addr 和 len 都相同的表项，则替换掉原有的。
 * 删除时按照 addr 和 len **精确** 匹配。
 */
void update(bool insert, RoutingTableEntry entry) {
  // TODO:
  // cout << "in lookup.cpp 1 \n";
  if(insert){
    // cout << "in lookup.cpp 2 \n";
    insertt(entry);
    // cout << "in lookup.cpp 3 \n";
  }
  else{
    // cout << "in lookup.cpp 4 \n";
    uint32_t addr = entry.addr;
    uint32_t len = entry.len;
    deletee(addr,len); 
    // cout << "in lookup.cpp 5 \n";
  }
}

/**
 * @brief 进行一次路由表的查询，按照最长前缀匹配原则
 * @param addr 需要查询的目标地址，网络字节序
 * @param nexthop 如果查询到目标，把表项的 nexthop 写入
 * @param if_index 如果查询到目标，把表项的 if_index 写入
 * @return 查到则返回 true ，没查到则返回 false
 */
bool match(RoutingTableEntry now, uint32_t addr){
  uint32_t len = now.len;
  uint32_t save_addr = now.addr;
  if(len < 32){
    addr = addr & ((1 << len) - 1);
    save_addr = save_addr & ((1 << len) - 1);}
//if(addr == save_addr)
//  printf("addr = 0x%08x save_addr = 0x%08x \n", addr, save_addr);

  if(addr == save_addr)
    return true;
  else
    return false;
}

bool exact_match(RoutingTableEntry now, uint32_t addr, uint32_t mask) {
    uint32_t len = now.len;
    uint32_t save_addr = now.addr;
    // cout << "mask = " << mask << " " << " mask_len = " << ((1 << len) - 1) << endl;
    // printf("mask = 0x%08x\t((1 << len)-1) = 0x%08x\n", mask, ((1 << len)-1));
    if(addr == save_addr && ((1 << len)-1) == mask)
        return true;
    else
        return false;
}


bool exact_query(uint32_t addr, uint32_t mask, uint32_t &nexthop, uint32_t &if_index, uint32_t &metric) {          // 精确匹配
                                            // 找到精确匹配符合的表项
    for(int i = 0;i < begin_.size();i++){
        // cout << times++ << " nexthop = " << now->e.nexthop << " if_index = " << now->e.if_index << " len = " << now->e.len << " metric = " << now->e.metric << endl;
        if(exact_match(begin_[i], addr, mask)){
            nexthop = begin_[i].nexthop;
            if_index = begin_[i].if_index;
            metric = begin_[i].metric;
            return true;
        }
    }
    return false;
}
vector<RoutingTableEntry> ans;

vector<RoutingTableEntry> get_all_entries(){
  vector<RoutingTableEntry> vec;
  vec = begin_;
  return vec;
}

bool prefix_query(uint32_t addr, uint32_t *nexthop, uint32_t *if_index) {   // 最长前缀匹配
  // TODO:
  int leng = 0;
//    for(int i = 0;i < begin_.size();i++){   // 找到所有前缀匹配符合的表项
//        printf("addr = 0x%08x len = %d nexthop = 0x%08x if_index = %d\n", begin_[i].e.addr, begin_[i].e.len, begin_[i].e.nexthop, begin_[i].e.if_index);
//    }
    ans.clear();
    for(int i = 0;i < begin_.size();i++){
        if(match(begin_[i], addr)){
            ans.push_back(begin_[i]);
        }
    }
  int max_id = -1;
  int max = -1;
  for(int i = 0;i < ans.size();i++){
      // 从所有前缀匹配符合的表项中最长前缀匹配的表项
    if(max < int(ans[i].len)){
        max = ans[i].len;
        max_id = i;
    }
  }

//  cout << "========================\n";
//  if(leng > 0 && ans[max_id].e.addr == 0){
//      printf("special addr = 0x%08x len = %d nexthop = 0x%08x if_index = %d\n", ans[max_id].e.addr, ans[max_id].e.len, ans[max_id].e.nexthop, ans[max_id].e.if_index);
//  }
  auto tmp_nexthop = ans[max_id].nexthop;
  auto tmp_if_index = ans[max_id].if_index;
  if(max_id !=-1){
    *nexthop = tmp_nexthop;
    *if_index = tmp_if_index;
    return true;
  }

  *nexthop = 0;
  *if_index = 0;
  // // cout << "false !\n";
  return false;
}
