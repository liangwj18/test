#!/bin/bash
echo "Stop bird"
set -v

systemctl stop bird