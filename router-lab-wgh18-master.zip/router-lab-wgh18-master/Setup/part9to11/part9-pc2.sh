#!/bin/bash
set -v

ping 192.168.10.1
ping 192.168.255.1